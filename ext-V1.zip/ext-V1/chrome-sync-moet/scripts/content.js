// window.onload = function () {
//     appendExportButton();
// }

// /**
//  * Xử lý append button tải mẫu vào giao diện
//  */
// function appendExportButton() {
//     var interval = setInterval(function () {
//         var $grbts = $('.grbt-chucnang');
//         if ($grbts.length) {
//             $grbts.prepend('<input type="button" data-export-type="classroom" name="btnTaiExcelFromMISAEMIS" value="Tải file mẫu từ MISA EMIS" id="btnTaiExcelFromMISAEMIS" class="btn btn-primary" />')
//             initEvents();
//             clearInterval(interval);
//         }
//     }, 100);
// }

// /**
//  * Init events
//  */
// function initEvents() {
//     $(document).on('click', '#btnTaiExcelFromMISAEMIS', function () {
//         var $btn = $(this);

//         chrome.extension.sendMessage({
//             type: 'export',
//             data: {
//                 type: $btn.data('export-type')
//             }
//         });
//     });
// }