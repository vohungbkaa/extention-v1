/**
 * Config
 */
var _mainConfig = {
    authenApi: 'https://emisapp.misa.vn/apis/r/external/api/mimosa/authenticate',
    exportApi: '',
    logoutApi: ''
};

/**
 * Login
 * @param {string} command 
 * @param {object} item 
 * @param {event} e 
 */
function loginAction(command, item, e) {
    var param = {
        'Username': $('#txtUserName').val(),
        'Password': $('#txtPassword').val(),
        'BudgetCode': $('#txtOrganization').val(),
        'ApplicationCode': 'MIMOSA'
    };

    AjaxJSON(_mainConfig.authenApi, {}, param, function(msg) {
        if (msg.Success) {
            //Lưu thông tin authen + đơn vị
            localStorage.setItem('Token', msg.Data);
            //Dùng token => Lấy dữ liệu thống kê
            updateUI();
        } else {
            console.log('Thông tin đăng nhập không hợp lệ');
        }
    }, function(res) {});
}

/**
 * logout
 * @param {string} command 
 * @param {object} item 
 * @param {event} e 
 */
function logoutAction(command, item, e) {
    localStorage.removeItem('Token');
    updateUI();
    $('#txtOrganization').focus();
}

/**
 * Xử lý command trên form
 * @param {string} command 
 * @param {object} item 
 * @param {event} e 
 */
function itemCommandClick(command, item, e) {
    switch (command) {
        case 'login':
            loginAction(command, item, e);
            break;

        case 'logout':
            logoutAction(command, item, e);
            break;

        case 'introduction':
            gotoFormGroupContent()
            break;

        case 'export-student':
            exportCSDLQD()
                //exportData()
            break;

        default:
            break;
    }
}

/**
 * Show/hide UI
 */
function updateUI() {
    var loginPage = $('#login-page'),
        mainPage = $('#main-page');

    //Kiểm tra có token chưa
    if (localStorage.getItem('Token')) {

        //Nếu đã có token => Lấy dữ liệu thống kê
        loginPage.hide();
        mainPage.show()
            //Nếu token đã hết hạn hoặc không hợp lệ => show màn hình đăng nhập
    } else {
        loginPage.show();
        mainPage.hide();
    }
}

/**
 * Vào màn hình xuất khẩu
 */
function gotoFormGroupContent() {
    var loginPage = $('#login-page'),
        mainPage = $('#main-page'),
        lsItemExpoert = $('#list-item-export'),
        introductionView = $('#introduction-view');

    loginPage.hide();
    mainPage.show();
    lsItemExpoert.hide();
    introductionView.removeClass('d-none');
}

/**
 * Xử lý xuất khẩu cơ sở dữ liệu quốc gia
 */
function exportCSDLQD() {
    var param = {
        exportOption: [3],
        isByClass: false,
        semester: 1
    };

    AjaxJSON('https://emisapp.misa.vn/rc/StudentV3/Api/Export/ExportCSDLQG', {}, param, function(res) {
        if (res.Success) {
            var urlExport = `${'https://emisapp.misa.vn'}${res.Data}`
            exportData(urlExport)
        } else {
            console.log('Thông tin đăng nhập không hợp lệ');
        }
    }, function(res) {});
}

/**
 * Xử lý khi page ready
 */
$(document).ready(function() {
    updateUI();
    $(document).on('click', '[data-command]', function(e) {
        var item = $(this),
            command = item.data('command');

        if (command) {
            itemCommandClick(command, item, e);
        }

    });
});