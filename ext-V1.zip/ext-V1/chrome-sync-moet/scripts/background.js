function getDownloadInfo() {
    var downloadInfo = null;
    try {
        downloadInfo = JSON.parse(localStorage.downloadInfo);
    } catch (e) {
        localStorage.downloadInfo = JSON.stringify(downloadInfo);
    }
    return downloadInfo;
}

function setDownloadInfo(info) {
    localStorage.downloadInfo = JSON.stringify(info);
}

/**
 * Xử lý msg
 */
chrome.extension.onMessage.addListener(
    function(request) {
        switch (request.type) {
            case 'export':
                exportData(request.data);
                break;
        }
    });


/**
 * Xử lý event download
 */
chrome.downloads.onChanged.addListener(function(delta) {
    try {

        if (!delta.state || (delta.state.current != 'complete')) {
            if (delta.filename && delta.filename.current) {
                var downloadInfo = getDownloadInfo();
                if (downloadInfo && downloadInfo['DownloadId'] == delta.id) {
                    downloadInfo['Filename'] = delta.filename.current;
                    setDownloadInfo(downloadInfo);
                }
            }
            return;
        } else if (delta.state && delta.state.current == 'complete') {
            var downloadInfo = getDownloadInfo();
            if (downloadInfo && downloadInfo['DownloadId'] == delta.id) {
                alert(JSON.stringify(downloadInfo));
                chrome.downloads.open(downloadInfo['DownloadId']);
            }
        }
    } catch (ex) {
        console(ex);
    }
});

/**
 * Xuất khẩu dữ liệu từ MISA EMIS
 * @param {Tham số xuất khẩu dữ liệu} data 
 */
function exportData(exportUrl) {
    chrome.downloads.download({
            url: exportUrl,
            headers: [
                { name: 'authorization', value: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiJiYWNjNzRkOC1hNzdmLTRjM2MtOGFlOC0yOWYzNjg5OGMyZjkiLCJVc2VyTmFtZSI6ImFkbWluIiwiT3JnYW5pemF0aW9uSUQiOiI5YThmNjU3ZC1iMGJjLTRmMmEtOWQwYS1lYjYwYTE0YjYxNWQiLCJBcHBsaWNhdGlvbnMiOiIiLCJVc2VyUm9sZSI6IjYsMSIsIm5iZiI6MTYyNDMyNDk4NCwiZXhwIjoxNjI0NDExMzg0LCJpYXQiOjE2MjQzMjQ5ODQsImlzcyI6InFsdGhhcHAubWlzYS52biJ9.AIctM4779A8E_zLs8mv6WBUmIezofwDAP2Z_hDwfee8' }
            ]
        },
        function(downloadId) {
            var info = {
                DownloadId: downloadId
            };
            setDownloadInfo(info);
        });
}